/**
 * 
 */
/**
 * 
 */
module movie_ticket_booking_system {
	requires java.sql;
}